# Tomorrowland Easy Tent Telegram Bot

Телеграм-бот для мониторинга Tomorrowland Belgium 2026 по пакетам:
- Easy Tent Package
- Spectacular Easy Tent
- Supreme Easy Tent
- DreamVille Easy Tent

Площадки:
- TicketSwap
- StubHub
- Viagogo
- HelloTickets
- Gigsberg

Расписание:
- 10:00
- 15:00
- 20:00
- Часовой пояс: Europe/Warsaw

## Что бот делает

Бот открывает страницы площадок через Playwright, вытягивает текст страницы и ищет упоминания нужных пакетов. Если находит новые совпадения, отправляет сообщение в Telegram.

## Важное ограничение

Эти сайты часто меняют разметку, могут показывать разный контент по географии, антибот-защите и cookie-экранам. Поэтому это **рабочий бот-скелет**, но ему может понадобиться одна разовая подстройка под реальные страницы: например, добавить обработку cookie-баннеров или перейти с поиска по полному тексту на точечные CSS/XPath-селекторы.

## Как запустить

### 1) Создай бота в Telegram
1. Открой `@BotFather`
2. Команда `/newbot`
3. Скопируй токен

Telegram Bot API — это HTTP API для ботов, а создавать бота нужно через BotFather. Официальная документация Telegram это подтверждает. citeturn0search2turn0search5

### 2) Узнай свой chat_id
Самый простой путь:
- запусти бота
- напиши ему `/start`
- временно добавь в код лог `update.effective_chat.id`

Или используй любой удобный метод получения chat id через Bot API.

### 3) Установи зависимости
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m playwright install chromium
```

Playwright официально поддерживает Python и умеет запускать Chromium, WebKit и Firefox. citeturn0search1turn0search7

### 4) Создай `.env`
Скопируй `.env.example` в `.env` и заполни:
```env
TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHAT_ID=...
TIMEZONE=Europe/Warsaw
HEADLESS=true
SEARCH_TIMEOUT_MS=30000
STATE_FILE=state.json
```

### 5) Запусти
```bash
python bot.py
```

## Команды
- `/start` — краткая справка
- `/check` — проверить площадки сейчас
- `/status` — показать настройки
- `/clear_seen` — очистить историю найденных совпадений

## Почему именно такое расписание
Библиотека `python-telegram-bot` поддерживает `JobQueue`, а `JobQueue` использует APScheduler для периодических задач. Это подтверждено официальной документацией. citeturn0search0turn0search6

## Как улучшить надёжность

Если хочешь сделать бота действительно боевым, следующий шаг:
1. добавить отдельные селекторы для каждой площадки;
2. закрывать cookie-баннеры;
3. сохранять не только текст, но и найденные карточки лотов;
4. присылать цену и прямую ссылку на конкретный лот, а не только страницу;
5. запускать бота на VPS или Railway/Render.

## Юридический и практический момент
Перед автопроверкой площадок посмотри их условия использования. Некоторые сайты ограничивают автоматизированный доступ. Кроме того, наличие лота на ресейле не гарантирует валидность входа на Tomorrowland.
