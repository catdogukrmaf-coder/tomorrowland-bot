# Самый простой вариант: бот работает в облаке, а на iPhone нужен только Telegram

## Что важно понять
Этот бот **нельзя установить на iPhone как обычное приложение, которое само крутится в фоне 24/7**. На iPhone он так не заработает.

Правильная схема такая:
- бот живёт в облаке
- ты пользуешься им через приложение Telegram на iPhone
- когда бот находит Easy Tent / Spectacular / Supreme, он пишет тебе в Telegram

## Самый простой запуск без программирования: Render + Telegram

### Шаг 1. Создай Telegram-бота
1. Открой Telegram
2. Найди `@BotFather`
3. Отправь команду `/newbot`
4. Придумай имя и username
5. Скопируй **bot token**

Официально Telegram рекомендует создавать ботов через `@BotFather`. citeturn0search0turn0search6

### Шаг 2. Узнай свой chat_id
1. Напиши своему боту `/start`
2. Открой в браузере:
   `https://api.telegram.org/botТОКЕН/getUpdates`
3. Найди `chat":{"id":123456789...}`
4. Скопируй это число — это и есть `TELEGRAM_CHAT_ID`

Telegram Bot API — это HTTP API, через которое бот получает и отправляет сообщения. citeturn0search3

### Шаг 3. Залей папку с ботом на GitHub
Нужно создать приватный репозиторий и загрузить туда файлы из этой папки.

### Шаг 4. Задеплой на Render
1. Зайди в Render
2. New + → Blueprint
3. Выбери свой GitHub-репозиторий
4. Render увидит файл `render.yaml`
5. Введи переменные:
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_CHAT_ID`
6. Нажми Deploy

У Render есть отдельный тип сервиса **Background Worker** для постоянно работающих процессов. citeturn0search2turn0search11turn0search17

### Шаг 5. Готово
После запуска бот сам проверяет площадки в:
- 10:00
- 15:00
- 20:00
по Europe/Warsaw и пишет тебе в Telegram.

Периодические задачи в `python-telegram-bot` работают через `JobQueue`. citeturn0search1turn0search19

## Что отслеживает бот
- Easy Tent Package
- Spectacular Easy Tent
- Supreme Easy Tent
- DreamVille Easy Tent

Площадки:
- TicketSwap
- StubHub
- Viagogo
- HelloTickets
- Gigsberg

## Команды в Telegram
- `/start`
- `/status`
- `/check`
- `/clear_seen`

## Честно про ограничения
- TicketSwap почти наверняка бесполезен для Tomorrowland из-за персонализированных билетов
- у resale-сайтов часто антибот-защита
- иногда нужно подправлять селекторы или ждать загрузку страницы дольше
- для 100% стабильности может понадобиться доработка под конкретные сайты

## Если тебе нужен совсем “без кода” путь
Тогда нужен не этот бот, а отдельный человек/сервис, который:
- создаст бота
- зальёт код в облако
- подключит аккаунты
- протестирует уведомления

Итог: **на iPhone ты ничего не устанавливаешь кроме Telegram. Бот должен работать в облаке.**
