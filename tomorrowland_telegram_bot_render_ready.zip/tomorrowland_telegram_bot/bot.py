import asyncio
import json
import logging
import os
import re
from dataclasses import dataclass
from datetime import time
from pathlib import Path
from typing import Iterable, List

from dotenv import load_dotenv
from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
)
from zoneinfo import ZoneInfo

from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError


load_dotenv()

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

TZ = ZoneInfo(os.getenv("TIMEZONE", "Europe/Warsaw"))
STATE_FILE = Path(os.getenv("STATE_FILE", "state.json"))
SEARCH_TIMEOUT_MS = int(os.getenv("SEARCH_TIMEOUT_MS", "30000"))
HEADLESS = os.getenv("HEADLESS", "true").lower() == "true"

WANTED_KEYWORDS = [
    "easy tent",
    "spectacular easy tent",
    "supreme easy tent",
    "dreamville easy tent",
]
EXCLUDED_KEYWORDS = [
    "full madness",
    "day pass",
    "magnificent greens",
]

PLATFORMS = [
    {
        "name": "TicketSwap",
        "url": "https://www.ticketswap.com/festival-tickets/a/tomorrowland-belgium",
    },
    {
        "name": "StubHub",
        "url": "https://www.stubhub.com/tomorrowland-festival-tickets/grouping/150299040",
    },
    {
        "name": "Viagogo",
        "url": "https://www.viagogo.com/Festival-Tickets/International-Festivals/Tomorrowland-Festival-Tickets",
    },
    {
        "name": "HelloTickets",
        "url": "https://www.hellotickets.com/tomorrowland-tickets/p-31105",
    },
    {
        "name": "Gigsberg",
        "url": "https://www.gigsberg.com/festival-tickets/international-festivals/tomorrowland-tickets",
    },
]


@dataclass
class Hit:
    platform: str
    url: str
    matched_keywords: List[str]
    excerpt: str

    @property
    def dedupe_key(self) -> str:
        return f"{self.platform}|{self.url}|{'/'.join(sorted(self.matched_keywords))}|{self.excerpt[:120]}"


class StateStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.data = {"seen": []}
        if path.exists():
            try:
                self.data = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                logger.exception("Failed to load state; starting fresh")

    def seen(self, key: str) -> bool:
        return key in set(self.data.get("seen", []))

    def mark_seen(self, keys: Iterable[str]) -> None:
        seen = set(self.data.get("seen", []))
        seen.update(keys)
        self.data["seen"] = sorted(seen)
        self.path.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")


state = StateStore(STATE_FILE)


def normalize_text(text: str) -> str:
    text = re.sub(r"\s+", " ", text)
    return text.strip().lower()


async def collect_page_text(page, url: str) -> str:
    await page.goto(url, wait_until="domcontentloaded", timeout=SEARCH_TIMEOUT_MS)
    try:
        await page.wait_for_load_state("networkidle", timeout=5000)
    except PlaywrightTimeoutError:
        pass
    body_text = await page.locator("body").inner_text(timeout=SEARCH_TIMEOUT_MS)
    return normalize_text(body_text)


async def scan_platform(browser, platform: dict) -> List[Hit]:
    context = await browser.new_context(locale="en-GB")
    page = await context.new_page()
    hits: List[Hit] = []
    try:
        text = await collect_page_text(page, platform["url"])
        matched = [kw for kw in WANTED_KEYWORDS if kw in text]
        excluded = [kw for kw in EXCLUDED_KEYWORDS if kw in text]
        if matched:
            excerpt_source = text
            excerpt = excerpt_source[:500]
            if excluded:
                excerpt += f" | excluded terms also seen: {', '.join(excluded)}"
            hits.append(
                Hit(
                    platform=platform["name"],
                    url=platform["url"],
                    matched_keywords=matched,
                    excerpt=excerpt,
                )
            )
    except Exception as e:
        logger.warning("Scan failed for %s: %s", platform["name"], e)
    finally:
        await context.close()
    return hits


async def run_scan() -> List[Hit]:
    results: List[Hit] = []
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=HEADLESS)
        try:
            tasks = [scan_platform(browser, platform) for platform in PLATFORMS]
            nested_results = await asyncio.gather(*tasks)
            for items in nested_results:
                results.extend(items)
        finally:
            await browser.close()
    return results


async def send_hits(chat_id: int, bot, hits: List[Hit], *, prefix: str = "🔔 Найдено") -> None:
    if not hits:
        await bot.send_message(chat_id=chat_id, text="Сейчас подходящих лотов не найдено.")
        return

    new_hits = [hit for hit in hits if not state.seen(hit.dedupe_key)]
    if not new_hits:
        await bot.send_message(chat_id=chat_id, text="Новых лотов нет. Похожее уже находилось раньше.")
        return

    lines = [f"{prefix} {len(new_hits)} вариант(а/ов):"]
    for hit in new_hits:
        lines.append(
            f"\n• <b>{hit.platform}</b>\n"
            f"Совпадения: {', '.join(hit.matched_keywords)}\n"
            f"URL: {hit.url}\n"
            f"Фрагмент: {hit.excerpt[:280]}..."
        )

    state.mark_seen([hit.dedupe_key for hit in new_hits])
    await bot.send_message(chat_id=chat_id, text="\n".join(lines), parse_mode=ParseMode.HTML, disable_web_page_preview=True)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = (
        "Привет! Я мониторю Tomorrowland Belgium 2026 по Easy Tent и выше.\n\n"
        "Ищу только: Easy Tent Package, Spectacular Easy Tent, Supreme Easy Tent, DreamVille Easy Tent.\n"
        "Площадки: TicketSwap, StubHub, Viagogo, HelloTickets, Gigsberg.\n\n"
        "Команды:\n"
        "/check — проверить сейчас\n"
        "/status — показать настройки\n"
        "/clear_seen — забыть уже найденные совпадения"
    )
    await update.message.reply_text(msg)


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "Мониторинг включён. Расписание: 10:00, 15:00, 20:00 Europe/Warsaw.\n"
        f"Отслеживаемые платформы: {', '.join(p['name'] for p in PLATFORMS)}"
    )


async def clear_seen(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    state.data = {"seen": []}
    STATE_FILE.write_text(json.dumps(state.data, ensure_ascii=False, indent=2), encoding="utf-8")
    await update.message.reply_text("История найденных совпадений очищена.")


async def check_now(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("Проверяю площадки…")
    hits = await run_scan()
    await send_hits(update.effective_chat.id, context.bot, hits, prefix="🔎 Проверка завершена.")


async def scheduled_check(context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = context.job.chat_id
    logger.info("Running scheduled check for chat_id=%s", chat_id)
    hits = await run_scan()
    if not hits:
        return
    await send_hits(chat_id, context.bot, hits)


async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.exception("Unhandled error", exc_info=context.error)


def main() -> None:
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        raise RuntimeError("Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in .env")

    application = Application.builder().token(token).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("status", status))
    application.add_handler(CommandHandler("check", check_now))
    application.add_handler(CommandHandler("clear_seen", clear_seen))
    application.add_error_handler(on_error)

    for hour in (10, 15, 20):
        application.job_queue.run_daily(
            scheduled_check,
            time=time(hour=hour, minute=0, tzinfo=TZ),
            name=f"scheduled-check-{hour}",
            chat_id=int(chat_id),
        )

    logger.info("Bot started")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
